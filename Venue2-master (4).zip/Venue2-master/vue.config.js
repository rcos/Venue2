module.exports = {
  pwa: {
    themeColor: '#FFFFFF',
    msTileColor: '#FFFFFF',
    manifestOptions: {
      background_color: '#FFFFFF'
    },
    name: "Venue",
    workboxOptions: {
      skipWaiting: true,
    },
  }
}
