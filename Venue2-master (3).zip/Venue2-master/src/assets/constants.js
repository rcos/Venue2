let Constants = {
  colors: ['Aquamarine', 'Tomato', 'LightSalmon', 'Cyan', 'MediumTurquoise', 'PaleGreen', 'pink', 'violet', 'aqua', 'BurlyWood', 'Chartreuse', 'Crimson', 'CadetBlue', 'Chocolate', 'BlueViolet', 'DarkRed', 'Lime', 'PowderBlue']
}

export default Constants
